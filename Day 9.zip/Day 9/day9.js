function chaimg1(){
    document.getElementById("trns1").src="Images/dog.jpg"
}
function chaimg2(){
    document.getElementById("trns1").src="Images/mountain.jpg"
}
function chaimg3(){
    document.getElementById("trns1").src="Images/seal.jpg"
}